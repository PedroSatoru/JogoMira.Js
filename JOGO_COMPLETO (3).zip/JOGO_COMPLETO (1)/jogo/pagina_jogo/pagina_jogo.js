
var musica = new Audio('musicadefundo.mp3');
musica.loop = true;
musica.play()